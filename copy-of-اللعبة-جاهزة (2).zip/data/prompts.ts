
/**
 * تعليمات الفئات (Category Specific Prompts)
 * تم إفراغ هذا الملف بناءً على طلب المستخدم لحذف الأنماط المخصصة للمجموعات.
 */

export const GROUP_INSTRUCTIONS: Record<string, string> = {};

export const CATEGORY_PROMPTS: Record<string, string> = {};
