
/**
 * 🚩 تم إيقاف هذا الملف نهائياً واستبداله بـ سجل Supabase
 */
export const historyService = {
  saveQuestions: () => {},
  getHistory: () => [],
  clearHistory: () => {}
};
