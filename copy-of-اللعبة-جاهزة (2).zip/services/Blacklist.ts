
/**
 * 🚩 تم إيقاف هذا الملف نهائياً واستبداله بـ services/supabase.ts
 */
export const Blacklist = {
  get: async () => [],
  append: async () => {}
};
